package enums

const (
	TicketStatusPending   = "pending"
	TicketStatusActive    = "active"
	TicketStatusUsed      = "used"
	TicketStatusCancelled = "cancelled"
)
