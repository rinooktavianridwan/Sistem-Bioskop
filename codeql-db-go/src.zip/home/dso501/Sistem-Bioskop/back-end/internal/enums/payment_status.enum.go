package enums

const (
    PaymentStatusPending   = "pending"
    PaymentStatusSuccess   = "success"
    PaymentStatusFailed    = "failed"
)