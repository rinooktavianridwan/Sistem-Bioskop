package constants

const (
    JobTypeMovieReminder     = "notification:movie_reminder"
    JobTypePromoNotification = "notification:promo_notification"
    JobTypeBookingConfirm    = "notification:booking_confirmation"
)