package constants

const (
    PaymentStatusPending   = "pending"
    PaymentStatusSuccess   = "success"
    PaymentStatusFailed    = "failed"
)