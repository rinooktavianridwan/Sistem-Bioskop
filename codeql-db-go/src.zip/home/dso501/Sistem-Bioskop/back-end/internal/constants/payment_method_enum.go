package constants

const (
	PaymentMethodCreditCard = "credit_card"
    PaymentMethodEWallet    = "e_wallet"
)