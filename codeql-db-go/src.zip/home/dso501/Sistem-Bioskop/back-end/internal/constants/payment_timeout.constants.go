package constants

const (
	TypePaymentTimeout = "payment:timeout"
)