package constants

const (
	TicketStatusPending   = "pending"
	TicketStatusActive    = "active"
	TicketStatusUsed      = "used"
	TicketStatusCancelled = "cancelled"
)
