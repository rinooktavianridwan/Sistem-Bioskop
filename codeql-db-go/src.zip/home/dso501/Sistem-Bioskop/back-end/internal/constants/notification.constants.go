package constants

const (
    NotificationTypeMovieReminder     = "movie_reminder"
    NotificationTypePromoAvailable    = "promo_available"
    NotificationTypeBookingConfirm    = "booking_confirmation"
    NotificationTypeSystem           = "system"
)