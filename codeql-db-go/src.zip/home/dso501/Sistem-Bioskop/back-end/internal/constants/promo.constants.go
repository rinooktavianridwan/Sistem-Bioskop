package constants

const (
    DiscountTypePercentage = "percentage"
    DiscountTypeFixedAmount = "fixed_amount"

	PromoStatusActive   = true
    PromoStatusInactive = false
)